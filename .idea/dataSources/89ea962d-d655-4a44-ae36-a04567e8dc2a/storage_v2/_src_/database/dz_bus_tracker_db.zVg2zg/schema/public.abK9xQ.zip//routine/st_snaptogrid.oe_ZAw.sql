create function st_snaptogrid(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_SnapToGrid($1, 0, 0, $2, $2)$$;

alter function st_snaptogrid(geometry, double precision) owner to postgres;

